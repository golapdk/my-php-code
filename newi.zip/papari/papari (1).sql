-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2017 at 10:16 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `papari`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

CREATE TABLE IF NOT EXISTS `bank_details` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_branch` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `IFSC` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_holder_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `children`
--

CREATE TABLE IF NOT EXISTS `children` (
  `id` int(10) unsigned NOT NULL,
  `father` int(11) NOT NULL,
  `child_a` int(11) DEFAULT NULL,
  `child_b` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `children`
--

INSERT INTO `children` (`id`, `father`, `child_a`, `child_b`, `created_at`, `updated_at`) VALUES
(23, 14, 15, 16, '2017-06-30 02:20:16', '2017-06-30 02:20:16'),
(26, 15, 17, 18, '2017-06-30 02:31:07', '2017-06-30 02:31:07'),
(27, 16, 19, 20, '2017-06-30 02:31:56', '2017-06-30 02:31:56'),
(28, 17, 21, 22, '2017-06-30 02:37:22', '2017-06-30 02:37:22'),
(29, 18, NULL, NULL, '2017-06-30 02:43:23', '2017-06-30 02:43:23'),
(30, 19, NULL, NULL, '2017-06-30 02:48:06', '2017-06-30 02:48:06'),
(31, 20, NULL, NULL, '2017-06-30 02:57:51', '2017-06-30 02:57:51'),
(32, 21, NULL, NULL, '2017-06-30 03:03:40', '2017-06-30 03:03:40'),
(33, 22, NULL, NULL, '2017-06-30 03:09:03', '2017-06-30 03:09:03');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2017_06_02_192653_create_users_table', 1),
(3, '2017_06_02_193528_create_successes_table', 2),
(4, '2017_06_02_193913_create_payments_table', 3),
(5, '2017_06_02_194115_create_bank_details_table', 4),
(6, '2017_06_02_194714_create_children_table', 5),
(7, '2017_06_12_174826_create_requests_table', 6),
(8, '2017_06_29_182856_create_money_table', 7);

-- --------------------------------------------------------

--
-- Table structure for table `money`
--

CREATE TABLE IF NOT EXISTS `money` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `money` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `money`
--

INSERT INTO `money` (`id`, `user_id`, `money`, `created_at`, `updated_at`) VALUES
(13, 14, '229.33333333333334', '2017-06-30 02:31:07', '2017-06-30 02:31:07'),
(14, 15, '151.42857142857142', '2017-06-30 02:37:22', '2017-06-30 02:37:22'),
(15, 16, '100', '2017-06-30 02:48:06', '2017-06-30 02:48:06'),
(16, 17, '100', '2017-06-30 03:03:40', '2017-06-30 03:03:40');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `payment`, `created_at`, `updated_at`) VALUES
(23, 14, 1, '2017-06-30 02:20:16', '2017-06-30 02:20:16'),
(26, 15, 1, '2017-06-30 02:31:07', '2017-06-30 02:31:07'),
(27, 16, 1, '2017-06-30 02:31:56', '2017-06-30 02:31:56'),
(28, 17, 1, '2017-06-30 02:37:21', '2017-06-30 02:37:21'),
(29, 18, 1, '2017-06-30 02:43:23', '2017-06-30 02:43:23'),
(30, 19, 1, '2017-06-30 02:48:05', '2017-06-30 02:48:05'),
(31, 20, 1, '2017-06-30 02:57:51', '2017-06-30 02:57:51'),
(32, 21, 1, '2017-06-30 03:03:39', '2017-06-30 03:03:39'),
(33, 22, 1, '2017-06-30 03:09:03', '2017-06-30 03:09:03');

-- --------------------------------------------------------

--
-- Table structure for table `request_friends`
--

CREATE TABLE IF NOT EXISTS `request_friends` (
  `id` int(10) unsigned NOT NULL,
  `father` int(11) NOT NULL,
  `child_one` int(11) NOT NULL,
  `child_two` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `request_friends`
--

INSERT INTO `request_friends` (`id`, `father`, `child_one`, `child_two`, `created_at`, `updated_at`) VALUES
(5, 14, 15, 16, '2017-06-30 02:22:45', '2017-06-30 02:22:45'),
(6, 15, 17, 18, '2017-06-30 02:36:01', '2017-06-30 02:36:01'),
(7, 16, 19, 20, '2017-06-30 02:36:41', '2017-06-30 02:36:41'),
(8, 17, 21, 22, '2017-06-30 03:03:01', '2017-06-30 03:03:01');

-- --------------------------------------------------------

--
-- Table structure for table `successes`
--

CREATE TABLE IF NOT EXISTS `successes` (
  `id` int(10) unsigned NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `success` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `successes`
--

INSERT INTO `successes` (`id`, `phone_number`, `user_id`, `success`, `created_at`, `updated_at`) VALUES
(23, '9401305930', 14, 1, '2017-06-29 07:00:00', '2017-06-29 07:00:00'),
(24, '9401763645', 15, 1, '2017-06-30 02:22:45', '2017-06-30 02:22:45'),
(25, '9954466403', 16, 1, '2017-06-30 02:22:45', '2017-06-30 02:22:45'),
(26, '9101090633', 17, 1, '2017-06-30 02:36:01', '2017-06-30 02:36:01'),
(27, '1234567890', 18, 1, '2017-06-30 02:36:01', '2017-06-30 02:36:01'),
(28, '1111111111', 19, 1, '2017-06-30 02:36:41', '2017-06-30 02:36:41'),
(29, '2222222222', 20, 1, '2017-06-30 02:36:41', '2017-06-30 02:36:41'),
(30, '3333333333', 21, 1, '2017-06-30 03:03:01', '2017-06-30 03:03:01'),
(31, '4444444444', 22, 1, '2017-06-30 03:03:01', '2017-06-30 03:03:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `otp` int(11) NOT NULL,
  `otp_count` int(11) NOT NULL,
  `new_otp` int(11) DEFAULT NULL,
  `verify` int(11) NOT NULL,
  `stage` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `phone_number`, `name`, `password`, `otp`, `otp_count`, `new_otp`, `verify`, `stage`, `created_at`, `updated_at`) VALUES
(14, '9401305930', 'golap hazarika', '$2y$10$MmqlNZ/RZWqG8mkSDAzZuu5GwkSh4INTbjS5hpDHkeTMwHujxzcV.', 1234, 1, NULL, 1, 5, '2017-06-13 01:42:46', '2017-06-30 02:22:45'),
(15, '9401763645', 'papari', '$2y$10$sDnEXxwxg9fOesp/pA1dq.TsblSVZ/cCxG1vyajE0e1LTQZ3uCEGu', 1234, 1, NULL, 1, 5, '2017-06-13 01:48:52', '2017-06-30 02:36:01'),
(16, '9954466403', 'prahlad', '$2y$10$/7PmWLBsAFE0cZdfIYnkjOocQM8BByodV/oFw6KoUVME4/ImSZjDm', 1234, 1, NULL, 1, 5, '2017-06-13 01:49:41', '2017-06-30 02:36:41'),
(17, '9101090633', 'golap new', '$2y$10$shJPapDyc8tnXqTAaUL.QODShwgTYDSMXylpjpm0Ezjp/.ftN8CfC', 1234, 1, NULL, 1, 5, '2017-06-13 01:50:31', '2017-06-30 03:03:01'),
(18, '1234567890', '1234', '$2y$10$z0cWTpGfuKGYw8vdJM8JQOjSBNX0O0njLSk5GpbCJFNXkeH/Vd1GC', 1234, 1, NULL, 1, 4, '2017-06-13 01:51:07', '2017-06-30 02:43:23'),
(19, '1111111111', 'bappi', '$2y$10$xR/xjE/a8IMTpCAwdp5IyOqTRm1PiroIDmdjkGQ8tzZ3qWAvcWzIu', 1234, 1, NULL, 1, 4, '2017-06-30 02:34:24', '2017-06-30 02:48:05'),
(20, '2222222222', 'himanshu', '$2y$10$tMge29HvkWGbjk94E9iVQupUOHDN3jiSRVo3/N8YNklpiU.nAZIPW', 1234, 1, NULL, 1, 4, '2017-06-30 02:35:01', '2017-06-30 02:57:51'),
(21, '3333333333', 'mridu', '$2y$10$yZuKlP7yt2YZ8fDbuSgzfOReeVndjUuoMZ.PPfIYrIy/mDciX6qtu', 1234, 1, NULL, 1, 4, '2017-06-30 03:01:15', '2017-06-30 03:03:40'),
(22, '4444444444', 'chandan', '$2y$10$s5QEAFI9kZlUz50paLoBGuCguTCgpxr/B55ZcCSii8DPggQFZyhEK', 1234, 1, NULL, 1, 4, '2017-06-30 03:02:02', '2017-06-30 03:09:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_details`
--
ALTER TABLE `bank_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `children`
--
ALTER TABLE `children`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `money`
--
ALTER TABLE `money`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request_friends`
--
ALTER TABLE `request_friends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `successes`
--
ALTER TABLE `successes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_details`
--
ALTER TABLE `bank_details`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `children`
--
ALTER TABLE `children`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `money`
--
ALTER TABLE `money`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `request_friends`
--
ALTER TABLE `request_friends`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `successes`
--
ALTER TABLE `successes`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
