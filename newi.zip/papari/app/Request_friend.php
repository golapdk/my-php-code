<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Request_friend extends Model
{
  protected $fillable = ['father', 'child_one','child_two'];

}
