<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Input;
use App\Success;
use App\Request_friend;
use App\Adduser;
use Tymon\JWTAuth\Facades\JWTAuth;

use Tymon\JWTAuth\Exceptions\JWTException;
class SelectchildController extends Controller
{


    public function index(Request $request)
    {

      $users = User::where('verify', '=', 1)->where('stage', '=', 2)->get();

      $user_add_check = User::where('phone_number',$request->phone_number)->first();
      if ($user_add_check->stage <5) {
        $addUser_check = 'active';
      }
      else {
        $addUser_check = 'deactive';
      }

      return Response()->json(['success'=>true, 'users'=>$users , 'addUser_check'=>$addUser_check]);



    }
    public function store(Request $request)
    {

      // $input = Input::all();
      //dd($request->phone_numbers);
$currentUser_phone_number = $request->currentUser_phone_number;
$first_phone_numbers = $request->first_phone_numbers;
$second_phone_numbers = $request->second_phone_numbers;
// dd($first_phone_numbers);


if($first_phone_numbers != null) {
  $child_one = $first_phone_numbers;

  $child_one_user_id = User::where('phone_number',$child_one)->first();

  if ($child_one_user_id) {
    $check1= Success::where('phone_number', $child_one)->count();
    if (!$check1) {


    $success_one = new Success;
    $success_one->phone_number = $child_one;
    $success_one->user_id = $child_one_user_id->id;
    $success_one->success = 1;
    $success_one->save();


    $update_stage_user=User::where('phone_number' ,$child_one )->first();

    $update_stage_user->update([ 'stage' => 3]);
    $update_currentuser_stage=User::where('phone_number' ,$currentUser_phone_number )->first();

    if ($update_currentuser_stage->stage == 5) {
      $update_currentuser_stage->update([ 'stage' => 6]);

    }elseif ($update_currentuser_stage->stage < 5) {
      $update_currentuser_stage->update([ 'stage' => 5]);

    }

    $request_child = new Request_friend;
    $request_child->father = $update_currentuser_stage->id;
    $child_one_id=User::where('phone_number' ,$child_one )->first();
    // $child_two_id=User::where('phone_number' ,$child_two )->first();
    $request_child->child_one = $child_one_id->id;
    // $request_child->child_two = $child_two_id->id;
    $request_child->save();

    }
  }else {
    $this->addUser($child_one, $currentUser_phone_number);
  }


}
if($second_phone_numbers != null) {
  $child_two = $second_phone_numbers;

  $child_two_user_id = User::where('phone_number',$child_two)->first();

  if ($child_two_user_id) {
    $check2= Success::where('phone_number', $child_two)->count();

    if (!$check2) {


    $success_one = new Success;
    $success_one->phone_number = $child_two;
    $success_one->user_id = $child_two_user_id->id;
    $success_one->success = 1;
    $success_one->save();

    $update_stage_user=User::where('phone_number' ,$child_two )->first();

    $update_stage_user->update([ 'stage' => 3]);
    $update_currentuser_stage=User::where('phone_number' ,$currentUser_phone_number )->first();

    if ($update_currentuser_stage->stage == 5) {
      $update_currentuser_stage->update([ 'stage' => 6]);

    }elseif ($update_currentuser_stage->stage < 5) {
      $update_currentuser_stage->update([ 'stage' => 5]);

    }
    $request_child = new Request_friend;
    $request_child->father = $update_currentuser_stage->id;
    $child_two_id=User::where('phone_number' ,$child_two )->first();
    // $child_two_id=User::where('phone_number' ,$child_two )->first();
    $request_child->child_two = $child_two_id->id;
    // $request_child->child_two = $child_two_id->id;
    $request_child->save();

  }else {
    dd('ErrorException');
  }
  }else {
    $this->addUser1($child_two, $currentUser_phone_number);
  }


}






// $update_currentuser_stage=User::where('phone_number' ,$request->currentUser_phone_number )->first();
//
// $update_currentuser_stage->update([ 'stage' => 5]);
//
// $request_child = new Request_friend;
// $request_child->father = $update_currentuser_stage->id;
// $child_one_id=User::where('phone_number' ,$child_one )->first();
// $child_two_id=User::where('phone_number' ,$child_two )->first();
// $request_child->child_one = $child_one_id->id;
// $request_child->child_two = $child_two_id->id;
// $request_child->save();


  return Response()->json(['success'=>true, 'message'=>'Successfully submitchild ']);

    }

public function addUser($child_one, $currentUser_phone_number)
{

$check = Adduser::where('user_id',$currentUser_phone_number)->count();


if ($check <2) {



if ($child_one != null) {

$owner_id = User::where('phone_number',$currentUser_phone_number)->first()->id;
  $add_user_one = new Adduser;
  $add_user_one->phone_number =$child_one;
  $add_user_one->user_id = $owner_id;
  $link = str_random(50);
  $add_user_one->link = $link.$currentUser_phone_number;

 $add_user_one->save();

 $update_currentuser_stage=User::where('phone_number' ,$currentUser_phone_number )->first();

 if ($update_currentuser_stage->stage == 5) {
   $update_currentuser_stage->update([ 'stage' => 6]);

 }elseif ($update_currentuser_stage->stage < 5) {
   $update_currentuser_stage->update([ 'stage' => 5]);

 }
$weblink='localhost:8000/#/register/'.$link.$currentUser_phone_number;

  }



}else {
  dd('error');
}


}
public function addUser1($child_two, $currentUser_phone_number)
{

$check = Adduser::where('user_id',$currentUser_phone_number)->count();


if ($check <2) {



if ($child_two != null) {

$owner_id = User::where('phone_number',$currentUser_phone_number)->first()->id;
  $add_user_one = new Adduser;
  $add_user_one->phone_number =$child_two;
  $add_user_one->user_id = $owner_id;
  $link = str_random(50);
  $add_user_one->link = $link.$currentUser_phone_number;

 $add_user_one->save();

 $update_currentuser_stage=User::where('phone_number' ,$currentUser_phone_number )->first();

if ($update_currentuser_stage->stage == 5) {
  $update_currentuser_stage->update([ 'stage' => 6]);

}elseif ($update_currentuser_stage->stage < 5) {
  $update_currentuser_stage->update([ 'stage' => 5]);

}

$weblink='localhost:8000/#/register/'.$link.$currentUser_phone_number;

  }



}else {
  dd('error');
}


}


}
