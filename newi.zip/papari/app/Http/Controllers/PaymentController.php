<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Payment;
use App\Child;
use App\Request_friend;
use DB;
use App\Money;
class PaymentController extends Controller
{

    public function index()
    {
      # code...
    }
    public function store(Request $request)
    {

      $users_id= User::where('phone_number', $request->phone_number)->first()->id;

      $check= Payment::where('user_id', $users_id)->where('payment','=', 1)->count();
      if ($check == 0) {
        $payment = [];
        $payment = array_add($payment, 'user_id', $users_id);
        $payment = array_add($payment, 'payment', 1);
         Payment::create($payment);
        $verifyuser=User::where('phone_number' ,$request->phone_number )->first();

    $verifyuser->update(['stage' => 4]);

$father_check_one = Request_friend::where('child_one', $verifyuser->id)->count();

if ($father_check_one) {
  $father_check = Request_friend::where('child_one', $verifyuser->id)->first();

  $relation = Child::where('father' ,$father_check->father )->first();

  if ($relation->child_one == NULL) {


    DB::table('children')
                ->where('father', $father_check->father)
                ->update(['child_a' => $verifyuser->id]);


  }
}
$father_check_two = Request_friend::where('child_two', $verifyuser->id)->count();
if ($father_check_two) {
    $father_check = Request_friend::where('child_two', $verifyuser->id)->first();
    $relation_again = Child::where('father' ,$father_check->father )->first();
  if ($relation_again->child_two == NULL) {

    DB::table('children')
                ->where('father', $father_check->father)
                ->update(['child_b' => $verifyuser->id]);

  }



}

        $request_child = new Child;
        $request_child->father = $verifyuser->id;

        $request_child->child_a = NULL;
        $request_child->child_b = NULL;
          $request_child->save();




$this->sendRequest($users_id);


        return Response()->json(['success'=>true, 'message'=>'Payment Successfully', 'Payment' => 1]     ) ;

      }else {
          return Response()->json(['success'=>false, 'message'=>'Payment faild', 'Payment' => 0]);
      }



    }
    public function sendRequest($users_id)
    {



$nexts=DB::select(DB::raw("SELECT  @r AS _id,
   (
   SELECT  @r := father
   FROM    children
   WHERE   child_a = _id or child_b = _id
   ) AS father,
   @l := @l + 1 AS lvl
FROM    (
   SELECT  @r := $users_id,
           @l := 0,
           @cl := 0
   ) vars,
   children h
WHERE    @r <> 0"));
// $newValues = array();




//
// $string = '';
$value = 40;
$value_after =20;
// $devider = sizeof($nexts)-(sizeof($nexts)-(sizeof($nexts)/2));
$i = 0;
// dd(sizeof($nexts));
$nexts = collect($nexts);
$total_length = $nexts->where('father','!=', "");

$devider = $total_length->count();

foreach ($nexts as $next) {
  // $next->father;




// lenght uliyabo lagibo father valu jimnor ase hai loi and hai tu hisbe diveder ot set koribo lagibo



// dd($next->father);
if ($i == 0) {
  if ($next->father) {

    $get=50;
    $i++;

$get_user_money_table = Money::where('user_id', $next->father)->first();

if ($get_user_money_table) {
$total_money = $get_user_money_table->money +  $get;
      DB::table('money')
                  ->where('user_id', $next->father)
                  ->update(['money' => $total_money]);
}else {
  $money = new Money;
  $money->user_id = $next->father;

  $money->money = $get;

  $money->save();


}






  }else {
    $get = null;
    return Response()->json(['success'=>true, 'message'=>'Payment Successfully', 'Payment' => 1]     ) ;
  }

}

else {
  if ($next->father) {

    if ($i == 1 && $devider == 2 ) {
      $get1 = $value;


$i++;
$get_user_money_table = Money::where('user_id', $next->father)->first();
if ($get_user_money_table) {
$total_money1 = $get_user_money_table->money +  $get1;
      DB::table('money')
                  ->where('user_id', $next->father)
                  ->update(['money' => $total_money1]);
}else {
  $money = new Money;
  $money->user_id = $next->father;

  $money->money = $get1;

  $money->save();


}

    }
    elseif ($i == 1 && $devider > 2 ) {
      $get1a = $value/2;
      $value =[];
      $value = $get1a;


$i++;
$get_user_money_table = Money::where('user_id', $next->father)->first();
if ($get_user_money_table) {
$total_money1a = $get_user_money_table->money +  $get1a;
      DB::table('money')
                  ->where('user_id', $next->father)
                  ->update(['money' => $total_money1a]);
}else {
  $money = new Money;
  $money->user_id = $next->father;

  $money->money = $get1a;

  $money->save();


}
    }






    elseif ($i > 1) {
      $get2 = $value/2;
      $value =[];
      $value = $get2;
      $i++;


      $get_user_money_table = Money::where('user_id', $next->father)->first();

      if ($get_user_money_table) {
      $total_money2 = $get_user_money_table->money +  $get2;
            DB::table('money')
                        ->where('user_id', $next->father)
                        ->update(['money' => $total_money2]);
      }else {
        $money = new Money;
        $money->user_id = $next->father;

        $money->money = $get2;

        $money->save();


      }
    }




  }
  else {
    $get = null;
    return Response()->json(['success'=>true, 'message'=>'Payment Successfully', 'Payment' => 1]     ) ;
  }
}








// echo "$get\ngolap";
 // $string .= $next->father.',';
}
//
// dd($value);
// dd($nexts);
// dd($string);

return Response()->json(['success'=>true, 'message'=>'Payment Successfully', 'Payment' => 1]     ) ;
    }
}
