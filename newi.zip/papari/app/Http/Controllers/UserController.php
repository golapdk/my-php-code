<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Validator;
use App\User;
use Carbon\Carbon;
use Auth;
use JWTAuth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Mail;
// use Tymon\JWTAuthFacades\JWTAuth;
use App\Success;
use App\Adduser;
use App\Request_friend;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response

     */



    protected $rules = [

        'name' => ['required'],
        'phone_number' => ['unique:users','required'],
        'password' => ['required'],

    ];
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $v = Validator::make($request->all(), $this->rules);


     if ($v->fails())
     {

          return Response()->json(array('success' => false,'errors'=>$v->errors()), 500);
            // return redirect()->back()->withErrors($v->errors());
     }


            $input = Input::all();
            $pass = $input['password'];
            $pass = bcrypt($pass);
            $user = Input::only('name', 'phone_number');


            if ($request->link) {
              $link = $request->link;

            }
            else {
              $link = NULL;

            }

            // $dob = $input['dob'];
            // dd($dob);

            // $verification_code = str_random(50);
            $verification_code = 1234;
            $user = array_add($user, 'password', $pass);
            $user = array_add($user, 'otp', $verification_code);
            $user = array_add($user, 'link', $link);

            $user = array_add($user, 'verify', 0);

            $user = array_add($user, 'otp_count', 1);
            $user = array_add($user, 'stage', 1);

   User::create($user);
   // dd('abc');
   //          Mail::send('emails.emailConfirm', ['user'=>$user,],function($message) use ($user)
   //       {

   //          $message->to($user['email'], $user['name'])->from('golapyd@gmail.com','Mywallz Care')->subject("MyWallz Email Varification");

   //       });


                 return Response()->json(array('success' => true, 'message'=>'Thanks for signing up! ' , 'register_user' => $user));



    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function checkmobilenumber($mobile_no)
    {

        $count = User::where('contact_no' ,$mobile_no )->count();

        if($count==0)
            return Response()->json(array('success'=>true,'message' => 'Number is available'),200);
        else
            return Response()->json(array('success'=>false,'error' => 'Number already taken'),500);


    }

public function otpverify(Request $request )
{


$otp=implode("|",$request->otp);
  $userotp_check = User::where('phone_number' ,$request->phone_number )->first();


  if ($otp == $userotp_check->otp) {

    $verifyuser=User::where('phone_number' ,$request->phone_number )->first();

    $verifyuser->update(['verify' => 1 , 'stage' => 2]);

      return Response()->json(array('success' => true,'message'=> 'otp match' , 'register_user' => $verifyuser));
  }else{
    return Response()->json(array('success' => false,'errors'=> 'otp not match'), 500);
  }

}
public function waitingforactivation(Request $request)
{

  $currentUser = User::where('phone_number', $request->phone_number)->first();
    //  $currentUser->update(['stage' => 3 ]);

  if ($currentUser->link) {
    $currentUser = User::where('phone_number', $request->phone_number)->first();
       $currentUser->update(['stage' => 3 ]);

    $count = Adduser::where('link',$currentUser->link)->count();
    if ($count) {
      $check = Adduser::where('link',$currentUser->link)->first();

      $parent_user = User::where('id',$check->user_id)->first();


if ($parent_user->stage == 6) {
$stage = 7;
}
elseif ($parent_user->stage == 7) {
  $stage = 8;
}

       $parent_user->update(['stage' => $stage ]);


      $success = [];
      $success = array_add($success, 'phone_number', $request->phone_number);

      $success = array_add($success, 'user_id', $currentUser->id);
      $success = array_add($success, 'success', 1);

 Success::create($success);

$fathers = Request_friend::where('father' ,$parent_user->id )->count();
if ($fathers) {

  $father = Request_friend::where('father' ,$parent_user->id )->first();
  if ($father->child_one == NULL) {
  $father->update(['child_one' => $currentUser->id ]);
  }
  if ($father->child_two == NULL) {
  $father->update(['child_two' => $currentUser->id ]);
  }
}else {
  $request_friend = [];
  $request_friend = array_add($request_friend, 'father', $parent_user->id);

  $request_friend = array_add($request_friend, 'child_one', $currentUser->id);
  $request_friend = array_add($request_friend, 'child_two', NULL);

 Request_friend::create($request_friend);
}





        return Response()->json(array('success' => true,'message'=> 'verify', 'active'=> 1));
    }

  }

  $activate_user_count = Success::where('phone_number',$request->phone_number)->where('success','=', 1)->count();

  if ($activate_user_count == 0) {
    return Response()->json(array('success' => false,'message'=> 'not activate please wait' , 'active'=> 0));
  }else{
    return Response()->json(array('success' => true,'message'=> 'verify', 'active'=> 1));
  }


}


}
