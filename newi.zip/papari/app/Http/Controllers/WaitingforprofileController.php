<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Request_friend;
use App\Payment;
class WaitingforprofileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
    $currentUser = User::where('phone_number', $request->phone_number)->first();

if ($currentUser->stage == 7) {
  return Response()->json(['success'=>true, 'message'=>'One user add', 'waitingforprofilestage' => 1]);
}
if ($currentUser->stage == 8) {
  return Response()->json(['success'=>true, 'message'=>'two user join', 'waitingforprofilestage' => 2]);
}
if ($currentUser->stage <= 6) {
  return Response()->json(['success'=>false, 'message'=>'no one join', 'waitingforprofilestage' => 0]);

}

// $check_user = Request_friend::where('father',$currentUser->id)->first();
// if ($check_user) {
// if ($check_user->child_one != NULL) {
//
// $child_one = $check_user->child_one;
// $child_one_payment = Payment::where('user_id',$child_one)->first();
// if ($child_one_payment) {
//   $profile = 1;
//
// }else {
//   $profile = 0;
// }
//
// }else {
// dd('kora nai');
// }
// if ($check_user->child_two != NULL) {
// dd('kora nai');
// }else {
//
//
//
//
// }
// }


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
