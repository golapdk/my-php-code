<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Payment;
use App\Child;
use App\Request_friend;
use DB;
use App\Money;
class moneygetdetailController extends Controller
{


public function index(Request $request)
{

  $user = User::where('phone_number',$request->phone_number)->first();


  $count = Money::where('user_id',$user->id)->count();
  if ($count) {

    $user_money = Money::where('user_id',$user->id)->first();

  }


  return Response()->json(['success'=>true, 'message'=>'Payment Successfully', 'user_money' => $user_money->money ]     ) ;


}




}
