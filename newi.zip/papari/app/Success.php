<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Success extends Model
{



 protected $fillable = ['phone_number','user_id','success'];

}
