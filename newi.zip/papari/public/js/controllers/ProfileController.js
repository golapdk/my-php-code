app.controller('ProfileController', function($scope,$auth,$state, $http, $rootScope,$stateParams) {





console.log($stateParams.phone_number);
getmoneydetails();

function getmoneydetails(){

          $http({
               method: 'GET',
               url: '/api/usermoneydetails?phone_number='+$stateParams.phone_number  ,

           }).success(function(data) {

       $scope.user_money= data.user_money;
      //        $scope.harmonizeId=data.harmonizeId;
      //        $scope.visitedUser=data.visitedUser
      //        console.log($scope.isharmonized);
  		// $scope.photos= data.photos;
  		// $scope.photoAlbums= data.photoAlbums;
      // console.log($scope.photoAlbums);
  		// $scope.hookonPhotos= data.hookon_photos;
      console.log($scope.user_money);


           }).error(function(error) {
               $scope.error = error;
           });
}

$scope.user_phone_number = $stateParams.phone_number;
});
