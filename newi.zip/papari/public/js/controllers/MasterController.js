app.controller('MasterController', function($scope,$auth,$state, $http, $rootScope) {


});