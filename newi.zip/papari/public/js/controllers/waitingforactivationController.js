app.controller('WaitingforactivationController', function($scope,$auth, $state, $http, $rootScope,$stateParams) {
console.log($stateParams.phone_number);
  $http({
    method: 'GET',
    url: '/api/waitingforactivation?phone_number='+$stateParams.phone_number,

  }).success(function(data){
    console.log(data);
    $scope.result = data.active;
    console.log($scope.result);
    if ($scope.result == 1) {
        $state.go('app.payment', {phone_number: $stateParams.phone_number});
    }

  }).error(function(error){
    $scope.error=error;
  });




});
