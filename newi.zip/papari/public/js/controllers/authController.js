app.controller('AuthController', function($scope,$auth,$state, $http, $rootScope,$stateParams) {

       $scope.login = function() {
console.log("pqr");
           var credentials = {
               phone_number: $scope.phone_number,
               password: $scope.password
           };

           $auth.login(credentials).then(function() {

                 return $http.get('api/authenticate/user');

             // Handle errors
             }, function(error) {
                 $scope.loginError = true;
                 $scope.loginErrorText = error.data.error;
                 $scope.loginErrorText = error.data.error;
                  $scope.loginErrorTextDisplay="Invalid Credentials";

             }).then(function(response) {
               console.log(response);

                 localStorage.setItem('users',angular.toJson(response.data.users));


                 $rootScope.authenticated = true;

                 $rootScope.currentUser = response.data.user;
                 console.log($rootScope.currentUser.phone_number);
if ($rootScope.currentUser.stage == 1) {
 $state.go('app.otpverify', {phone_number: $rootScope.currentUser.phone_number});

}else if ($rootScope.currentUser.stage == 2) {
   $state.go('app.waitingforactivation', {phone_number: $rootScope.currentUser.phone_number});

}else if ($rootScope.currentUser.stage == 3) {
   $state.go('app.payment', {phone_number: $rootScope.currentUser.phone_number});

}else if ($rootScope.currentUser.stage == 4) {
   $state.go('app.selectchild', {phone_number: $rootScope.currentUser.phone_number});

}else if ($rootScope.currentUser.stage == 5) {
  $state.go('app.selectchild', {phone_number: $rootScope.currentUser.phone_number});


}
else if ($rootScope.currentUser.stage == 8) {
  $state.go('app.profile', {phone_number: $rootScope.currentUser.phone_number});

}
else if ($rootScope.currentUser.stage == 6) {
  $state.go('app.waitingforprofile', {phone_number: $rootScope.currentUser.phone_number});

}
else if ($rootScope.currentUser.stage == 7) {
  $state.go('app.waitingforprofile', {phone_number: $rootScope.currentUser.phone_number});

}
                // $state.go('app.profile', {contact_no: $rootScope.currentUser.contact_no});
             });
       };

$scope.makeSignupActive=function(){

    $scope.actValue="signup";

 }

console.log($stateParams.link);
// signup process
$scope.submitUser = function(userData) {

  $http({
    method: 'POST',
    url: '/api/users?link='+$stateParams.link,

    data: userData
      }).success(function(data) {
 $scope.message=data.message;
 $scope.register_user = data.register_user;
 console.log($scope.register_user.phone_number);
 $state.go('app.otpverify',{ phone_number: $scope.register_user.phone_number});

      })
      .error(function(data) {
 $scope.errors=data.errors;
 $scope.message="";

      });



 };

// end signup process
// console.log($scope.register_user.phone_number);
$scope.otpverify = function (userData) {

  $http({
    method:'POST',
    url: '/api/usersotpverify',
    // data: userData,
    data : {
       otp:userData,
       phone_number:$stateParams.phone_number

    }
    // phone_number:$stateParams.phone_number,
  }).success(function (data) {
     $scope.register_user = data.register_user;
    console.log(data);
$state.go('app.waitingforactivation',{ phone_number: $scope.register_user.phone_number});
  })

}



// check mobile

$scope.checkmobile = function() {
  if($scope.userData.contact_no==null){
    return;
  }
  $http({
    method: 'GET',
    url: '/api/users/checkmobilenumber/'+$scope.userData.contact_no,
    headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }

      }).success(function(data) {
 $scope.contact_noText=data.message;
 $scope.contact_noTextError="";

      })
      .error(function(data) {
 $scope.contact_noTextError=data.error;
 $scope.contact_noText="";

      });


};
// end check mobile
});
