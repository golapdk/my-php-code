app.controller('PaymentController', function($scope,$auth, $state, $http, $rootScope,$stateParams) {
console.log($stateParams.phone_number);

$scope.paymentdone = function () {
  $http({
    method: 'POST',
    url: '/api/paymentdone?phone_number='+$stateParams.phone_number,

  }).success(function(data){
    console.log(data);
    $scope.result = data.Payment;
if ($scope.result == 1) {
  $state.go('app.selectchild', {phone_number: $stateParams.phone_number});
}

  }).error(function(error){
    $scope.error=error;
  });
}







});
