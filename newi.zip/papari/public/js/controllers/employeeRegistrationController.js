app.controller('employeeRegistrationController', function($scope,$state, $http, $rootScope) {



  $http.get('api/employees/getDepartmentList').success(function(data) {
  $scope.department_masters=data.department_masters;
  console.log($scope.department_masters);

  }).error(function(error) {
  $scope.error = error;
  });


  $http.get('api/employees/getDisciplineList').success(function(data) {
  $scope.discipline_masters=data.discipline_masters;
  console.log($scope.discipline_masters);

  }).error(function(error) {
  $scope.error = error;
  });

  $scope.employeeRegistration = function(employee) {
    // console.log(employee);

    $http({
          method: 'POST',
          url: '/api/employeeRegistrations',
    data : {
         employee:employee,

     }

      }).success(function(data) {
        console.log(data);
         })
         .error(function(data) {
             console.log(data);
         });
  }
});
