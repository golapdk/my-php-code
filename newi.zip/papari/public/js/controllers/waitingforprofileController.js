app.controller('WaitingforprofileController', function($scope,$auth, $state, $http, $rootScope,$stateParams) {
console.log($stateParams.phone_number);
  $http({
    method: 'GET',
    url: '/api/waitingforprofile?phone_number='+$stateParams.phone_number,

  }).success(function(data){

    $scope.result = data;
    console.log($scope.result);
    if ($scope.result.waitingforprofilestage == 2 ) {
        $state.go('app.profile', {phone_number: $stateParams.phone_number});
    }

  }).error(function(error){
    $scope.error=error;
  });




});
