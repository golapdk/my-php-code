app.controller('SelectchildController', function($scope,$auth, $state, $http, $rootScope,$stateParams) {
console.log($stateParams.phone_number);

  $http({
    method: 'GET',
    url: '/api/selectchild?phone_number='+$stateParams.phone_number,

  }).success(function(data){
    console.log(data);
     $scope.users = data.users;
     $scope.actValue = data.addUser_check;
     if ($scope.actValue != 'active') {
       $scope.add_first_user_list = 'none' ;
     }
     if ($scope.actValue == 'active') {
       $scope.add_first_user_list = 'active' ;
     }
  console.log($scope.users);
    // if ($scope.result == 1) {
    //     $state.go('app.selectchild', {phone_number: $stateParams.phone_number});
    // }

  }).error(function(error){
    $scope.error=error;
  });
  $scope.submitchild = function (multipleSelect) {




    $http({
          method: 'POST',
          url: '/api/submitchild',
    data : {
         first_phone_numbers:multipleSelect,
         currentUser_phone_number:$stateParams.phone_number,

     }

      }).success(function(data) {

  if (data.success == false) {
    $state.go('app.selectchild', {phone_number: $stateParams.phone_number}, {reload: true});

  }if (data.success == true) {
    $state.go('app.selectchild', {phone_number: $stateParams.phone_number}, {reload: true});

  }

         })
         .error(function(data) {
             console.log(data);

         });
  }
  $scope.submitchild1 = function (multipleSelect1) {




    $http({
          method: 'POST',
          url: '/api/submitchild1',
    data : {
         second_phone_numbers:multipleSelect1,
         currentUser_phone_number:$stateParams.phone_number,

     }

      }).success(function(data) {

  if (data.success == false) {
    $state.go('app.selectchild', {phone_number: $stateParams.phone_number});

  }if (data.success == true) {
    $state.go('app.waitingforprofile', {phone_number: $stateParams.phone_number});

  }

         })
         .error(function(data) {
             console.log(data);

         });
  }
console.log(  $scope.selectchild);
$scope.submitUser = function(userData) {
$scope.me = (userData.phone_number_one);
//   $http({
//     method: 'POST',
//     url: '/api/submitchild/addUser',
// data: {
//   add_user_one: userData.phone_number_one,
//   add_user_two: userData.phone_number_two,
//   owner:$stateParams.phone_number,
// }
//
//       }).success(function(data) {
//
//       })
//       .error(function(data) {
//  $scope.errors=data.errors;
//  $scope.message="";
//
//       });



 };





});
