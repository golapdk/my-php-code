angular.module('userService', [])

.factory('User', function($http) {

    return {
        // get all the comments

        // save a comment (pass in comment data)
        save : function(userData) {
            return $http({
                method: 'POST',
                url: '/api/users',
                headers: { 'Content-Type' : 'application/x-www-form-urlencoded' },
                data: $.param(userData)
            });
        },
        //check user name
        checkUserName : function(userData) {
            return $http({
                method: 'GET',
                url: '/api/users/checkusername/'+userData,
                headers: { 'Content-Type' : 'application/x-www-form-urlencoded' }

            });
        },
       editAbout:  function(userData){
         console.log(userData);
         return $http({
             method: 'PUT',
             url: '/api/users/'+userData.id,
           
             data: userData
         });
       },
        // destroy a comment
        destroy : function(id) {
            return $http.delete('/api/users/' + id);
        }
    }

});
